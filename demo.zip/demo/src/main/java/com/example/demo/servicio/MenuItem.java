package com.example.demo.servicio;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class MenuItem {
    private List<MenuItem> menuItems;

    public MenuItem() {
        menuItems = new ArrayList<>();
    }
    public  void addItem(int id,double precio){
        //boolean add = menuItems.add(new MenuItem(id, precio));
    }
    public List<MenuItem>getMenuItems(){
        return menuItems;
    }
}
