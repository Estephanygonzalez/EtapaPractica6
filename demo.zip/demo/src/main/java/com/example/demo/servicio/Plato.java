package com.example.demo.servicio;

import lombok.*;

@Data
@Builder
public class Plato {
    private String categoria;
    private String nombre;
    private String descripcion;
    private double precio;




}
