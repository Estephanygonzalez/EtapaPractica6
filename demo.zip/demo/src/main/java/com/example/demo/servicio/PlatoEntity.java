package com.example.demo.servicio;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class PlatoEntity {
    private @Id @GeneratedValue Long id;
    private String categoria;
    private String nombre;
    private String descripcion;
    private double precio;




}
