package com.example.demo.servicio;

import org.springframework.data.repository.CrudRepository;

public interface PlatoRepository extends CrudRepository<PlatoEntity,Long> {
}
