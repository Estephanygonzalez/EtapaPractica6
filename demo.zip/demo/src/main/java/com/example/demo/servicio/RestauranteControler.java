package com.example.demo.servicio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/restaurantedb")
public class RestauranteControler {
    @Autowired
    private RestauranteService restauranteService;
    @GetMapping
    public List<Plato> menuByOpcionSeleccionada (@RequestParam Integer opcionSeleccionada){
        return restauranteService.menuByOpcion(opcionSeleccionada);

    }

    /*@GetMapping("/{id}")
    public Optional<RestauranteService> menuByOpcionSeleccionada(@PathVariable("id") int id){
        return restauranteService.menuByOpcion(opcion);}*/
    @GetMapping("/especialdia")
    public List<Plato> listadosEspecialDia(){
        return restauranteService.especialDia();
    }

    @GetMapping("/especiales")//Servicio de tipo Get que hara una consulta de todos los platos Especiales
    public List<Plato> listadosPlatos(){
        return restauranteService.platosEspecialesv2();
    }
    //Necesitamos un servicio que me devuelva el desayunos
    @GetMapping("/ensaladas")
    public List<Plato> listadosEnsaladas(){
        return restauranteService.ensaladas();
    }
    @GetMapping("/desayunos")
    public List<Plato> listadosDesayuno(){
        return restauranteService.desayunos();
    }
    @GetMapping("/postres")
    public List<Plato> listadosPostres(){
        return restauranteService.postres();
    }
    @GetMapping("/adicionales")
    public List<Plato> listadosAdicionales(){
        return restauranteService.adicionales();
    }
    @GetMapping("/bebidas")
    public List<Plato> listadosBebidas(){
        return restauranteService.bebidas();
    }
}
