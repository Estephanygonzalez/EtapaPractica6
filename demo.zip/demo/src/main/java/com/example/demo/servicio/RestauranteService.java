package com.example.demo.servicio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RestauranteService {
    private static final double IVA = 0.05;//5%

    @Autowired
    PlatoRepository platoRepository;
    public List<Plato> menuByOpcion(Integer opcionSeleccionada) {
        double total = 0;
        String respuesta = "";
        switch (opcionSeleccionada) {
            case 1:
                return especialDia();
            case 2:
                return platosEspecialesv2();
            case 3:
                return ensaladas();
            case 4:
                return desayunos();
            case 5:
                return postres();
            case 6:
                return adicionales();
            case 7:
                return bebidas();
        }
        double totalConIVA = total + (total * IVA);//Iva del 5%

        return null;

        // return  respuesta + "Valor total con iva es:"+ totalConIVA;
    }


    List<Plato> especialDia() {
        Iterable<PlatoEntity> listadosEspecialDia = platoRepository.findAll();
        List<Plato> especialDia = new ArrayList<>();
        especialDia.add(Plato.builder().nombre("Churrasco").categoria("Especiales").descripcion("Pechuga a la plancha,Papas a la francesa,Ensalada,Arroz y Jugo de Mora").precio(23000).build());
        return especialDia;
    }
    List<Plato> platosEspecialesv2() {
        Iterable<PlatoEntity> listadosPlatos = platoRepository.findAll();
        List<Plato> platosEspeciales = new ArrayList<>();
        platosEspeciales.add(Plato.builder().nombre("Churrasco").categoria("Especiales").descripcion("sjdjsj").precio(23000).build());
        platosEspeciales.add(Plato.builder().nombre("Lomo de cerdo en salsa").categoria("Especiales").descripcion("hola").precio(24000).build());
        platosEspeciales.add(Plato.builder().nombre("Lengua en salsa").categoria("Especiales").descripcion("jsjs").precio(25000).build());
        return platosEspeciales;
    }

    List<Plato> ensaladas() {
        Iterable<PlatoEntity> listadosEnsaladas = platoRepository.findAll();
        List<Plato> platosEnsaladas = new ArrayList<>();
        platosEnsaladas.add(Plato.builder().nombre("Ensalada de vegetales").categoria("Ensaladas").descripcion("sjdjsj").precio(23000).build());
        platosEnsaladas.add(Plato.builder().nombre("Ensalada de frutas").categoria("Ensaladas").descripcion("hola").precio(24000).build());
        platosEnsaladas.add(Plato.builder().nombre("Ensalada de papa").categoria("Especiales").descripcion("jsjs").precio(25000).build());
        platosEnsaladas.add(Plato.builder().nombre("Ensalada de Zanahoria con  papa").categoria("Especiales").descripcion("jsjs").precio(25000).build());
        return platosEnsaladas;
    }
    List<Plato> desayunos() {
        Iterable<PlatoEntity> listadosDesayunos = platoRepository.findAll();
        List<Plato> platosDesayunos = new ArrayList<>();
        platosDesayunos.add(Plato.builder().nombre("Tamal con arepa y chocolate").categoria("Desayunos").descripcion("sjdjsj").precio(23000).build());
        platosDesayunos.add(Plato.builder().nombre("Caldo de pajarilla,arepa,chocolate y pan").categoria("Desayunos").descripcion("hola").precio(24000).build());
        platosDesayunos.add(Plato.builder().nombre("Caldo de costilla,arepa,chocolate y pan").categoria("Desayunos").descripcion("jsjs").precio(25000).build());
        platosDesayunos.add(Plato.builder().nombre("Calentado,arepa,chocolate y pan").categoria("Desayunos").descripcion("jsjs").precio(25000).build());
        return platosDesayunos;
    }

    List<Plato> postres() {
        Iterable<PlatoEntity> listadosPostres= platoRepository.findAll();
        List<Plato> platosPostres = new ArrayList<>();
        platosPostres.add(Plato.builder().nombre("Postre de Maracuyá").categoria("Postres").descripcion("sjdjsj").precio(23000).build());
        platosPostres.add(Plato.builder().nombre("Fland de Limón").categoria("Postres").descripcion("hola").precio(24000).build());
        platosPostres.add(Plato.builder().nombre("Helado").categoria("Postres").descripcion("jsjs").precio(25000).build());
        platosPostres.add(Plato.builder().nombre("Postre de Oreo").categoria("Postres").descripcion("jsjs").precio(25000).build());
        return platosPostres;
    }
    List<Plato> adicionales() {
        Iterable<PlatoEntity> listadosAdicionales = platoRepository.findAll();
        List<Plato> platosAdicionales = new ArrayList<>();
        platosAdicionales.add(Plato.builder().nombre("Pan").categoria("Adicionales").descripcion("sjdjsj").precio(23000).build());
        platosAdicionales.add(Plato.builder().nombre("Porción de papas").categoria("Adicionales").descripcion("hola").precio(24000).build());
        platosAdicionales.add(Plato.builder().nombre("salsas").categoria("Adicionales").descripcion("jsjs").precio(25000).build());
        platosAdicionales.add(Plato.builder().nombre("maduro").categoria("Adicionales").descripcion("jsjs").precio(25000).build());
        return platosAdicionales;
    }

    List<Plato> bebidas() {
        Iterable<PlatoEntity> listadosBebidas = platoRepository.findAll();
        List<Plato> bebidas = new ArrayList<>();
        bebidas.add(Plato.builder().nombre("Jarra de Jugo de Guanábana con Leche").categoria("Bebidas").descripcion("sjdjsj").precio(23000).build());
        bebidas.add(Plato.builder().nombre("Jarra de Jugo de Limonada  de Coco").categoria("Bebidas").descripcion("hola").precio(24000).build());
        bebidas.add(Plato.builder().nombre("1Litro de Gaseosa").categoria("Bebidas").descripcion("jsjs").precio(25000).build());
     bebidas.add(Plato.builder().nombre("Café").categoria("Bebidas").descripcion("").precio(25000).build());
        return bebidas;
    }

}